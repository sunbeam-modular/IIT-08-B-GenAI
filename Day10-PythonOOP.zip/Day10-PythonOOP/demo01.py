
class Person:
    pass

p1 = Person()
print(f"type(p1) = {type(p1)}")
print(f"p1 = {p1}")
print(f"addr of p1 = {id(p1)}")

p2 = Person()
print(f"type(p2) = {type(p2)}")
print(f"p2 = {p2}")
print(f"addr of p2 = {id(p2)}")
